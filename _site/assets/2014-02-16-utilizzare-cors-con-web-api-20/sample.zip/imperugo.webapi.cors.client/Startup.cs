﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(imperugo.webapi.cors.client.Startup))]
namespace imperugo.webapi.cors.client
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
