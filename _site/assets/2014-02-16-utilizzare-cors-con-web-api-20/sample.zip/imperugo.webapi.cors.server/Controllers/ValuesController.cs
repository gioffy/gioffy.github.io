﻿using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Cors;

namespace imperugo.webapi.cors.server.Controllers
{
	[EnableCors(origins: "http://imperclient.azurewebsites.net", headers: "*", methods: "*")]
	public class ValuesController : ApiController
	{
		// GET api/values/5
		public string Get()
		{
			return "This is my controller response";
		}
	}
}
